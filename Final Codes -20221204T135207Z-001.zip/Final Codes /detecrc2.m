function marques = detecrc2(senyal, mostrainicial, valormx, pres)
%DEFINICIONS
derSenyal = diff(senyal); %derivada
numostres = length(derSenyal); %nombre de mostres
offset = 50;
llindar = .5*max(derSenyal(1:2500)); %valor llindar=valor mig del valor màx de la derivada
comptador = 0;
mostra = mostrainicial; %mostra
bnd = 0;
marques = [];
mx = valormx;
% BUCLE PRINCIPAL DE CERCA
cont = 1; %activem "cont"
while cont
 if derSenyal(mostra) > llindar %si el valor de la derivada és major al llindar
 bnd = 0;
 cerca = 1; %activem "cerca"
 while cerca
 if derSenyal(mostra) < 0 %si el valor de la derivada és negativa(x<0)
 comptador = comptador + 1; %sumem al comptador
 marques(comptador, 1) = mostra; %guardem la mostra a marques(matriu)
 cerca = 0; %desactivem "cerca"
 llindar = mean([llindar
.4*max(derSenyal(mostra+offset:min([mostra+(2500) numostres])))]); %nou llindar
 mostra = mostra + offset; %avançament de l'offset
 if mostra >= numostres %mostra major o igual al nombre de mostres
 cont = 0; %desactivem "cont"
 end
 else %altre cas, derivada de la mostra es zero o positiva
 mostra = mostra + 1; %avançament de la mostra
 if mostra >= numostres %si el valor nou és major o igual al nombre de
mostres
 cont = 0; %desactivem "cont"
 end
 end
 end %finalitza el while ("cerca" ha d'estar desactivat)
 else %l'altre cas, derivada de la mostra menor o igual al llindar
 mostra = mostra + 1; %avançament de la mostra
 if mostra >= numostres %valor de la mostra major o igual al nombre de
mostres
 cont = 0; %desactivem "cont"
 end
 if mostra > 3000
 bnd = bnd + 1;
 end
 end
 if bnd > mx & length(marques)>0
 cont = 0; %desactivem "cont"
 end
end %finalitza el while ("cont" ha d'estar desactivat)
%%PLOTEJEM RESULTATS
t = (1/500:1/500:numostres/500)';
figure
hold on
plot(t, senyal(1:numostres),'blue');
plot(t, derSenyal, 'cyan');
plot(t, pres(1:numostres), 'red');
plot([marques marques]'/500, repmat(get(gca, 'Ylim')', size(marques')),'k--');
plot(t, pres(1:numostres), 'r.', 'MarkerIndices',[marques(1)
marques(end)],'MarkerSize',14);
%axis tight;
title('Pressure and korotkoff sounds')
xlabel('Time (s)')
ylabel('V(mV)')
legend('korotkoff signal','diff korotkoff signal')
hold off;
xlim([2 4]);
