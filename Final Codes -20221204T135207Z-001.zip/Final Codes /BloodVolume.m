load('ecgandpulse')
load('korotkoff')
normECG = detrend(ecg3, 'constant')/std(ecg3);
normPulse = detrend(pulse, 'constant')/std(pulse);
fm = 200;
numostres = length(normECG);
tMin = 1/fm;
tDelta = 1/fm;
tMax = numostres/fm;
t = (tMin:tDelta:tMax)';
%% Plot ECG3
figure;
plot(ecg3)
xlim([2700,3500])
ylim([-0.6,0.7])
title('ECG3 Arithmia (Atrial extrasystole)')
xlabel('marks')
ylabel('V(mV)')
%% BEATING DETECTION
marks = detecrc(ecg3);
%We determine the duration of beats 
duracio = diff(marks/fm);
% We determine heart rate (heart rate / min)
rate = 60./duracio;
%% Max pulse detection and peak voltage
numarks = length(marks);
% We determine value and position of the max pulse -> calculating max and min value between
% brands
% Max
for i=1:numarks-1
 [maxim(i), maxmark(i)]=max(pulse(marks(i):marks(i+1)));
 maxmark(i)=maxmark(i)+marks(i);% Corregim valor
end
% Mín
for k=1:numarks-1
[minim(k), marcaMn(k)]=min(pulse(marks(k):maxmark(k)));
marcaMn(k)=marcaMn(k)+marks(k);% Corregim valor
end
% Value drop by drop
for j=1:numarks-1
voltatgepp(j)=maxim(j)-minim(j);
end
%% DETERMINED HEART RACE THANKS TO THE PULSE
% Beats duration in seconds
beatdur = diff(maxmark/fm);
% Determine heart rate (beat / min)
ratecardiac = 60./beatdur;
figure
plot(ratecardiac)
%% T WAVE
% Determine the T wave
onaT = normECG(1425:1503);
marksT = detect(onaT, normECG, marks);
%R & T wave delay with max pulse
for i=1:numarks-2
retardR(i)=(maxmark(i)-marks(i))./fm;
end
for i=1:numarks-2
retardT(i)=(maxmark(i)-marksT(i))./fm;
end
%% Plots
%Pulse
figure;
plot(t,pulse,'m')
title('Pulse')
xlabel('time(s)')
ylabel('V(mV)')
%ECG3 and Pulse
figure;
hold on
plot(t,ecg3)
plot(t,pulse)
title('ECG3 and Pulse')
xlabel('time(s)')
ylabel('V(mV)')
xlim([20,21.5])
ylim([-0.6,0.7])
legend('ECG','Pulse')
hold off
%maxim pulse, minimum pulse and peak-to-peak value
figure;
hold on
plot(maxim, 'g');
plot(minim, 'b');
plot(voltatgepp, 'r');
axis tight;
title('maxim pulse, minimum pulse and peak-to-peak value')
ylabel('V (mV)');
xlabel('Beats');
hold off
% R and T delay (Pulse)
figure
subplot(2,1,1)
plot(retardR, 'r');
axis tight;
title('R wave and pulse delay');
xlabel('Time (s)');
ylabel('Delay (s)');
subplot(2,1,2)
plot(retardT, 'b');
axis tight;
title('T wave and pulse delay');
xlabel('Time (s)');
ylabel('Retard (s)');
hold off
%Cardiac Pulse
figure
hold on
plot(maxmark(1:end-1)/fm, ratecardiac, 'g');
axis tight;
xlabel('Time (s)');
ylabel('Rate (beats/min)');
title('Heart rate from maximum pulse');
%Heart rate form R wave
figure
hold on
plot(ritmecardiac, 'r');
axis tight;
xlabel('Beat');
ylabel('Rate (beats/min)');
title('Heart rate form R wave');
hold off