function Cardiac_Pulses(ecgsignal, psignal) 
% input = ecg signal and blood pressure signal
% output = graph with the cardiac pulse throughout the time obtained with 3
% diferent methods: using systolic pressures, diastolic pressures and
% detection of heart beats

close all; clc; % to clear the workspace, command window and to close all 
% existing figures
fm= 250;% in this case the sampling rate is 250

 % we obtain the marks for the systolic and dystolic pressures and the
 % heart beats, using the previous functions (detecps,detecpd and detecrc)
[marksSP]= detecps(psignal);
[marksDP]= detecpd(psignal);
[marks]=detecrc(ecgsignal);

% while plotting it we observed a false detection in mark 611 (caused by 
% some abnormality) so we delete it to allow a correct visualisation of the
% signal later
marks(611)=[]; 

% We obtain a vector of heartbeats for each method, using diff to know the
% difference between marks
dif_systolic= diff(marksSP);
s= fm*60./dif_systolic;  % by SYSTOLIC PRESSURES

dif_diastolic= diff(marksDP);
d= fm*60./dif_diastolic; % by DIASTOLIC PRESSURES

dif_rate= diff(marks);
r= fm*60./dif_rate; % by HEART BEATS

% PLOT
figure
hold on
plot(marksSP(1:end-1)/fm, s, 'b') % the vector s is one item smaller 
% because it's distances between marks, so we substract the last one.
axis tight;
title('Cardiac Pulse')
xlabel('time (s)')
ylabel('Cardiac Pulse (bpm)')
plot(marksDP(1:end-1)/fm, d,'r') % now we add the other two plots
plot(marks(1:end-1)/fm, r, 'g')
legend('Systolic','Diastolic','Heart Rate' )
hold off
xlim([2 14]); % this allows us to show only a limited part of the signal, 
% so that it's easier to analyse and compare
pan on; % activation of pan in both x and y axis

end

