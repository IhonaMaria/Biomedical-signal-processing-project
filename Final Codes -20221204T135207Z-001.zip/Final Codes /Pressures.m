function Pressures(psignal) %this function gives the systolic and diastolic 
% pressures for each pair of marks, as well as the pulse pressure and Mean 
% Arterial Pressure.
% RESULT:  4 figures, two of which correspond to the detecps and detecpd 
% functions. There will be another figure with all the diferent graphs, 
% and then a last figure with all the pressures overlapped.

close all; clc;  % to clear the command window and close all figures

load('senecg_fantasia.mat') % to load the signals that we will be using
load('senpre_fantasia.mat')

fm=250; % in this case the sampling rate is 250

%  - SYSTOLIC & DIASTOLIC PRESSURES -
% we use the function detecps and detecp to detect and mark the systolic 
% and diastolic pressures. these codes are a modified version of detecrc 
[marksSP]= detecps(psignal); 
[marksDP]= detecpd(psignal);

% now we'll represent both graphs
figure
hold on
subplot(2,2,1); % this allows us to put 4 graphs in the same figure (2x2)
plot(marksSP/fm, psignal(marksSP),'b') % we divide the x axis with fm to 
% obtain the graph in seconds, not positions or marks
axis tight;
title('Systolic Pressures')
xlabel('time (s)')
ylabel('pressure (mmHg)')

subplot(2,2,2) % we establish the position of the graph in the figure
plot(marksDP/fm, psignal(marksDP),'r')
axis tight;
title('Diastolic Pressures')
xlabel('time (s)')
ylabel('pressure (mmHg)')

%  - PULSE PRESSURE -
% knowing the systolic and diastolic pressures, we can obtain the pulse
% pressure by substracting one from the other:
pulse_pressure = psignal(marksSP)-psignal(marksDP);

subplot(2,2,3) % we add the graph to the figure in the third position
plot(marksSP/fm, pulse_pressure, 'g')
axis tight;
title('Pulse Pressure')
xlabel('time (s)')
ylabel('pressure (mmHg)')

%   - Mean Arterial Pressure (MAP) -
% once we have the pulse pressure we can obtain MAP with the next formula:
MAP = ((1/3)*pulse_pressure+psignal(marksDP));

subplot(2,2,4) % we add the graph to the figure
plot(marksDP/fm, MAP, 'm')
axis tight;
title('Medium Arterial Pressure (MAP)')
xlabel('time (s)')
ylabel('pressure (mmHg)')
hold off  % the figure is complete

%  <<PRESSURES GRAPH>>
% in this final graph we will overlap the 4 diferent pressures 
figure
hold on
subplot(1,1,1)
plot(marksSP/fm, psignal(marksSP),'b') 
axis tight;
title('Systolic, Diastolic, Pulse and Medium Arterial Pressures')
xlabel('time (s)')
ylabel('pressure (mmHg)')
plot(marksDP/fm,psignal(marksDP),'r')
plot(marksSP/fm, pulse_pressure, 'g')
plot(marksDP/fm, MAP, 'm')
legend('Systolic Pressure','Diastolic Pressure','Pulse Pressure', ...
    'Medium Arterial Pressure' )
hold off

% Now we determine the mean value of each (to have an orientative result)

Mean_Systolic_Pressure = mean(psignal(marksSP));
Mean_Systolic_Pressure
Mean_Diastolic_Pressure = mean(psignal(marksDP));
Mean_Diastolic_Pressure
Mean_Pulse_Pressure= mean(pulse_pressure);
Mean_Pulse_Pressure
Mean_Arterial_Pressure= mean(MAP);
Mean_Arterial_Pressure

end 