%% Beginning
clearvars; close all; clc;
%Upload the file
load senpre_fantasia;
load senecg_fantasia; 
%We normalized the signals
normECG = detrend(ecg1, 'constant')/std(ecg1);
fm = 250;
%% heartbeat detection
%we plot the detection of the R waves
marks = detecps(ecg1);
marks(611)=[] %we found this error mark 
nummarks = length(marks);
% We calculate the duration of the beats (in seconds)
durationns = diff(marks/fm);
% We calculate the heart rate in beats / minute
ritmes = 60./durationns;
%% calculations
markspsan = detecps(psan); %detect systolic pressure
% We want to find value and position of the systol --> we find the max value
% of the marks
for s=1:nummarks-1
[systole(s), marcasystole(s)]=max(psan(marks(s):marks(s+1)));
marcasystole(s)=marcasystole(s)+ marks(s);
end
% Determine the delay between one R and systolic pressure
for r=1:nummarks-1
retard(r)=(marcasystole(r)-marks(r))./fm;
end
%% T wave
OnaT = normECG(1370:1440);
marksT = detect(OnaT, normECG, marks);
% T wave delay and systolic pressure
for i=1:nummarks-2
retardT(i)=(marcasystole(i)-marksT(i))./fm;
end

%% Delay Wave R - Systolic Pressure
figure;
plot(retard, 'red')
title('R delay - Sysitolic pressure');
xlabel('marks');
ylabel('Delay');
%T Wave
figure;
plot(OnaT,'b');
title('T wave')
xlabel('marks')
%WE PLOT THE DELAY T
figure;
plot(retardT, 'blue');
axis tight;
title('T delay - Systolic pressure');
xlabel('marks');
ylabel('Delay');
%% mean
meanR = mean(retard)
meanT = mean(retardT)
