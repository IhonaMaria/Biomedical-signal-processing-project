function marquesT = detect(onaT, ecg, marquesECG)
[mx,posicio]=max(onaT);
longT = length(onaT);
longECG = length(ecg);
correl=zeros(size(1:longECG-longT+1));
pos=zeros(size(1:longECG-longT+1));
cont=1;
%Coefcorr màx i lags
for i=1:longECG-longT+1
 [corrfunc,lags]=xcorr(ecg(i:i+longT-1),onaT,30,'coeff');
 ind=find(lags==0);
 correl(i)=corrfunc(ind);
 pos(i)=posicio+i;
end
%Posició Ones T
for k=1:length(marquesECG)-2
 marc1=marquesECG(k);
 marc2=marquesECG(k+1);
 [ol1(cont),pos1(cont)]=max(correl(marc1:marc2));
 marquesT(cont)=pos1(cont)+marc1+posicio-1;
 cont=cont+1;
end
plot(correl)
end


