function marques = detecrc3(senyal,fs,llindar)
% DEFINICIONS
derSenal = diff(senyal); %derivada
numostres = length(derSenal); %nombre de mostres
offset = 100;
comptador = 0;
mostra = 1;
% BUCLE PRINCIPAL DE CERCA
cont = 1;%activem "cont"
while cont
 if derSenal(mostra) > llindar %si el valor de la derivada és major al llindar
 cerca = 1;%activem cerca
 while cerca
 if derSenal(mostra) < 0 %si el valor de la derivada és negativa(x<0)
 comptador = comptador + 1;%sumem al comptador
 marques(comptador, 1) = mostra; %guardem la mostra a marques(matriu)
 cerca = 0; %desactivem "cerca"
 llindar = mean([llindar
0.5*max(derSenal(mostra+offset:min([mostra+(2500) numostres])))]);%llindar pren un nou valor
 mostra = mostra + offset;%avançament de l'offset
 if mostra >= numostres %mostra major o igual al nombre de mostres
 cont = 0;%desactivem "cont"
 end
 else %altre cas, derivada de la mostra es zero o positiva
 mostra = mostra + 1; %avançament de la mostra
 if mostra >= numostres %si el valor nou és major o igual al nombre de
mostres
 cont = 0;%desactivem "continuar"
 end
 end
 end %finalitza el while ("cerca" ha d'estar desactivat)
 else %l'altre cas, derivada de la mostra menor o igual al llindar
 mostra = mostra + 1;%avançament de la mostra
 if mostra >= numostres %valor de la mostra major o igual al nombre de
mostres
 cont = 0; %desactivem "cont"
 end
 end
end %finalitza el while ("cont" ha d'estar desactivat)