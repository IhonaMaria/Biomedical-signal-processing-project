function heartrate (signal) %this function gives as a result the heartrate, 
% given a ecg signal
load senecg_fantasia; 
[marcas]=detecrc(signal); % we detect the beats using detecrc
y= length(marcas);
hr =(y/1200)*60; % we want the result in beats per minute
hr 
end 
