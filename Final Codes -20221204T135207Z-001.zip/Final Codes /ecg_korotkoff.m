
close all; clc; % to start clean
load korotkoff.mat
fm=500; 
%Superposition of ecg and the sounds
plot(ecg2)
hold on
axis tight
title('Superposition of ECG and Korotkoff Sounds')
ylabel('Voltage (mV)')
xlabel('Time (marks)')
plot(sons)
legend('ECG','Sounds')
xlim([1000 2000]) % we aply xlim to visualize correctly the ecg waves 
% with the sounds and detect where they appear
pan on % activates pan to navigate through the x and y axis
hold off


