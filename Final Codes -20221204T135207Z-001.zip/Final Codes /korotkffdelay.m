%% Beginning
clearvars; close all; clc;
%Upload the file
load 'korotkoff';
%We normalized the signals and we filter the signal used to search T waves
%because the program detect detect too the waves P and we dont want it. We
%found this freqüency playing with the filter.
[bfpa,afpa]= butter(6,1/250,'high');
ecg2f=filtfilt(bfpa,afpa,ecg2);
normECG = detrend(ecg2, 'constant')/std(ecg2);
normECGT = detrend(ecg2f, 'constant')/std(ecg2f);
Normpressure = detrend(pressio, 'constant')/std(pressio);
Normalizedsounds = detrend(sons, 'constant')/std(sons);
fm = 500;
marks4 = [];
marks5 = [];
numsample = length(Normalizedsounds);
tMin = 1/fm;
tDelta = 1/fm;
tMax = numsample/fm;
t = (tMin:tDelta:tMax)';
%% DETERMINE BEATS
markss= detecrc(ecg2f);
marks = detecrc(ecg2);
numarks = length(marks);
%% KOROTKOFF SOUNDS
%Detect start and end of intervals in the pressure signal
marks2 = detecrc(pressio);
marks2(7:1:9) = [];
%Start and end of each interval and detection of Korotkoff sounds
for i=1:length(marks2)+1
if i==1
in=1;
fi=marks2(1);
elseif i ==7
in=marks2(6);
fi=numsample;
else
in=marks2(i-1);
fi=marks2(i);
end
signal = sons(in:fi);
pres = 2*pressio(in:fi)/max(pressio);
switch i
case 2
inicialsample=5000;
diff=1200;
case {1,3,4,6}
inicialsample=2500;
diff=1200;
case 5
inicialsample=1500;
diff=500;
case 7
inicialsample=3500;
diff=1200;
end
marks3 = detecrc2(abs(signal),inicialsample, diff, pres);
marks3 = marks3+in-1;
inici(i) = marks3(1);
final(i) = marks3(end);
%Systole, Diastole
marks4 = [marks4 inici final];
%Korotkoff noise positions
marks5 = vertcat(marks5,marks3);
axis tight
end
%Correlation to adjust positions to actual noises
marks6 = [];
for i=1:length(marks5)
ind=marks5(i);
a1=ind-150;
a2=ind+150;
vec=sons(a1:a2);
[mx, pos] = max(vec);
pos=pos+a1-1;
marks6 = [marks6 pos];
end
%% T wave
% Definition of the wave T
onaT = normECGT(800:910);
% Detection waves
marksT = detect(onaT, normECGT, markss);
%% delayS
% Delay between R and Korotkoff noise
delayRK=zeros(170,1);
valorR = [];
for i=1:length(marks5)
j=1;
while marks5(i)-marks(j)>=0
j=j+1;
end
delayRK(j) = (marks5(i)-marks(j-1))./fm;
valorR = [valorR j];
end
% Delay between T and Korotkoff noise
delayTK=zeros(170,1);
valorT = [];
for i=1:length(marks5)
j=1;
while marks5(i)-marksT(j)>((marksT(j)-marksT(j+1))/2)
j=j+1;
end
delayTK(j) = (marks5(i)-marksT(j-1))./fm;
valorT = [valorT j];
end
%delay plots
figure;% dont run section, only works with normal run
hold on
plot(delayTK,'blue.', 'MarkerIndices', valorT,'MarkerSize',14);
plot(delayRK, 'red.', 'MarkerIndices', valorR,'MarkerSize',14);
axis tight;
title('R & T wave delay with Korotkoff sounds');
xlabel('Heartbeats');
ylabel('Delay(s)');
legend('T Delay','R Delay')
%% Plots
%ECG2 and sons
figure;
hold on
plot(ecg2)
plot(sons)
xlabel('marks')
xlim([3000,7000])
ylabel('Voltage (mV)')
ylim([-0.8,0.8])
hold off
figure;
hold on
plot(ecg2)
plot(sons)
xlabel('marks')
xlim([3800,4900])
ylabel('Voltage (mV)')
ylim([-0.8,0.8])
hold off
%Plot of systolic and diastolic blood pressure values by Korotkoff
figure;
plot(pressio(inici))
hold on
plot(pressio(final))
legend('systolic pressure','diastolic pressure')
hold off
title('Systolic and diastolic pressure calculated with korotkoff sounds')
xlabel('korotkoff sound')
ylabel('Pressure (mmHg)')
%Plot of Korotkoff sounds with marks
figure
hold on
plot(t, abs(sons), 'red');
title('Korotkoff Sounds')
plot(t, abs(sons), 'blue.', 'MarkerIndices', marks6,'MarkerSize', 14);
xlabel('Time(s)')
ylabel('V(mV)')
hold off;
%% mean R delay and T delay
delayTK(delayTK==0)=[];
delayRK(delayRK==0)=[];
meanT=mean(delayTK);
meanR=mean(delayRK);
