function hFig = dibuixar_senyals(senyals, fm, noms, marques, colorMarques, hFig)

  % dibuixarSenyals Dibuixa senyals i marques en una figura
  %
  % hFig = dibuixar_senyals(senyals, fm, noms, marques, colorMarques, hFig)
  %
  % Exemple:
  %
  %   senyal1 = randn(100000,1);
  %   senyal2 = randn(100000,1);
  %   marques1 = (15:150:10000)';
  %   marques2 = (30:300:10000)';
  %   fm = 100;
  %
  %   senyals = [senyal1 senyal2];
  %   fig = dibuixar_senyals(senyals, fm, {'S1','S2'}, marques1, [1 0 0]);
  %
  %   % Afegim mes marques a la figura (nomes es permet afegir marques)
  %   fig = dibuixarSenyals([], fm, [], marques2, [0 0 1], fig);
  %
  %   NOTA: NOMES FUNCIONA AMB MATLAB R2014B O MES RECENT.
  %
  %
  % HISTORIAL
  % ---------
  % CREAT:   Joan F. Alonso, 2015.10.25
  %
  % REVISAT: Joan F. Alonso, 2015.10.27
  % CANVIS:  - Ajust automatic de la mida dels elements de la figura.
  %          - Desplacament amb la roda del ratoli
  %          - Ajuda i exemple
  %

  %% INICIALITZACIO I GESTIO DELS ARGUMENTS
  narginchk(0,6);   % Comprovem que s'ha cridat la funcio usant entre 0 i 6 arguments d'entrada
  nargoutchk(0,1);  % Comprovem que s'ha cridat la funcio usant cap o 1 argument de sortida

  if verLessThan('matlab', '8.4')
    help dibuixar_senyals
    hFig = NaN;
    return;
  end
  
  tempsVisible = 5; % segons de senyal que es mostren a la figura
  midaPantalla = get(groot, 'ScreenSize');
  midaY = fix(.45*midaPantalla(4));
  midaX = fix(.85*midaPantalla(3));

  if nargin < 2
    help dibuixarSenyals
    hFig = NaN;
    return;
  end
  
  [numMostres, numSenyals] = size(senyals);
  if isscalar(fm) && fm > 0
    temps = (0:numMostres-1)/fm;
  else
    help dibuixar_senyals
    hFig = NaN;
    return;
  end
  
  if nargin < 3
    noms = [];
  end
  
  if nargin < 4
    marques = [];
  end
  
  if nargin < 5
    colorMarques = [0 0 0]; % Color negre per defecte
  end
  
  if nargin < 6
    % Figura
    hFig = figure(...
      'Name',' Revisio de senyals', ...
      'NumberTitle', 'off', ...
      'DockControls','off', ...
      'Position', centra_figura(midaX, midaY), ...
      'MenuBar', 'none', ...
      'ToolBar', 'none', ...
      'Units', 'pixels');
    hFig.SizeChangedFcn = @ajusta_mida; % No ho fem a la definicio anterior
                                        % per evitar errors (ajusta_mida fa servir hFig)
    hFig.WindowScrollWheelFcn = @scroll;
    
    % Eixos
    hAx = axes(...
      'Units', 'pixels', ...
      'FontSize', 9, ...
      'Ytick', [], ...
      'Position', [10 70 midaX-15 midaY-100], ...
      'Box', 'On', ...
      'Visible', 'On', ...
      'SortMethod', 'ChildOrder', ...
      'NextPlot', 'Add', ...
      'Layer', 'Top', ...
      'XMinorTick', 'On', ...
      'Parent', hFig);
    title(hAx, 'P3 Lab PSB', 'FontWeight', 'Bold', 'FontSize', 11);
    xlabel('temps (s)');
    
    if numSenyals > 0
      hAx.YLim = [min(min(senyals)) max(max(senyals))] + [-0.1 0.1]*(max(max(range(senyals))));
      
      % Slider horitzontal
      hSlider = uicontrol('Style', 'slider', ...
        'Min', temps(1), ...
        'Max', temps(end)-tempsVisible, ...
        'Value', temps(1), ...
        'SliderStep', [0.5*tempsVisible tempsVisible]/(numMostres/fm), ...
        'Units', 'pixels', ...
        'Position', [10 5 midaX-15 15]);
      hAx.XLim = temps(1)+[0 tempsVisible]; % Ajustem l'eix horitzontal visible
      
      % Creem un 'listener' que executara una funcio cada vegada que canvii 'Value'
      addlistener(handle(hSlider), 'Value', 'PostSet', @ajusta_eix_horitzontal);
    end
  else
    % Recuperem els eixos de la figura ja existent. No cal regenerar
    % l'Slider. L'escala vertical es manté.
    hAx = findobj(hFig, 'Type', 'Axes');
  end
  
  
  %% DIBUIXEM ELS SENYALS
  if numSenyals > 0
    plot(temps, senyals, ...
      'LineWidth', 1.25, ...
      'Parent', hAx);
  end
  if not(isempty(noms))
    if verLessThan('matlab', '9.2')
      legend(noms);
    else
        legend(noms, 'AutoUpdate', 'Off');
    end
  end
  
  
  %% DIBUIXEM LES MARQUES
  if not(isempty(marques))
    plot([marques(:) marques(:)]'/fm, ...
      repmat(hAx.YLim', 1, length(marques(:))), ...
      'Color', colorMarques, ...
      'LineStyle', '-');
    text((marques/fm)+(0.01*mean(diff(marques)))/fm, ...
      repmat(hAx.YLim(2)-(hAx.YLim(2)-hAx.YLim(1))*.05, size(marques)), ...
      cellstr(num2str((1:length(marques))')), ...
      'Color', colorMarques);
  end
  drawnow;
  
  
  %% CALLBACKS
  function ajusta_eix_horitzontal(~, evData)
    hAx.XLim = evData.AffectedObject.Value+[0 tempsVisible];
  end

  function ajusta_mida(~,~)
    hSlider.Position = [10 5 hFig.Position(3)-15 15];
    hAx.Position = [10 70 hFig.Position(3)-15 hFig.Position(4)-100];
  end

  function scroll(~, evData)
    if evData.VerticalScrollCount > 0 
      hSlider.Value = max(hSlider.Value-tempsVisible/2, hSlider.Min);
    elseif evData.VerticalScrollCount < 0
      hSlider.Value = min(hSlider.Value+tempsVisible/2, hSlider.Max);
    end
  end
   
  %% FUNCIONS AUXILIARS
  function pos = centra_figura(midaX, midaY)
    screenSize = get(0, 'ScreenSize');
    pos = [ceil((screenSize(3)-midaX)/2) ceil((screenSize(4)-midaY)/2), midaX, midaY];
  end

end