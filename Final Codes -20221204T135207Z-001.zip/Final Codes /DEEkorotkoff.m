%% Beginning
clc, close all, clear all
%Upload the file
load 'korotkoff';
fs = 500;
t = (1:length(sons))'/fs;
% DEFINE PEAKS OF KOROTKOFF NOISES.
limit = 0.6; % limit for the detection
marks = detecrc3(sons,fs,limit); % We call the function designed.
% Elimination of marks,  limiting pressure to 65-135 mmHg
marks2 = [];
for j = (1:length(marks))
 if and(65 <= pressio(marks(j)),pressio(marks(j)) <= 135)
 marks2(end+1) = marks(j);
 end
end
marks2= marks2';
%% korotkoff final marks
figure;
hold on
plot(t, sons,'k')
axis tight
plot([marks2 marks2]'/fs, repmat(get(gca, 'Ylim')', size(marks2')), 'blue')
xlabel('Time (s)')
ylabel('Voltage (mV)')
title('Korotkoff sounds marks')
hold off
%% WE FOUND THE DEE FOR EACH SOUND.
DEE = {};
MeanFreq= [];
MedianFreq= [];
nummeasure = 1; % 7 diferent sounds
p = 140;
for i=(1:length(marks2))
 A = sons(marks2(i)-35:marks2(i)+44);

 %Hanning

 N = length(A);
 w = hann(N);
 newA = A.*w;

 %DFT
 Nfft = 3000;
 DFT = fft(newA, Nfft);
 %DEE
 U = sum(w.^2)/N;
 dee = (abs(DFT).^2)/(fs*U);
 DEE{end+1} = dee;

 %Mean and median frequency
 dee2 = dee(1: Nfft/2+1); % 1/2 DEE

 f = ((0:Nfft-1)*fs/Nfft)'; % Calculation of the frequencies of the dee
 f2 = f(1: Nfft/2+1); % We limit the frequencies "1/2"

 [fmedia, fmediana] = fmnmd(dee2, f2); % We calculate the frequency

 MeanFreq(end+1) = fmedia;
 MedianFreq(end+1) = fmediana;

 % Plot DEE and frequencies
 name = ["Sound 1","Sound 2","Sound 3","Sound 4","Sound 5","Sound 6","Sound 7"];
 if or(pressio(marks2(i)) > p, i == length(marks2)) % últim soroll de la mesura-->pressio anterior és major
 figure
 % DEE.
 subplot(2,1,1)
 hold on
 xlabel('Frequency(Hz)')
 ylabel('DEE')
 title(name(nummeasure))
 for j=(1:length(DEE))
 plot(f,DEE{j}/max(DEE{j}))
 axis ([0 250 0 1])
 end

 hold off

 % Medium and medium frequency graphs
 subplot(2,1,2)
 hold on
 ylabel('Frequency (Hz)')
 title('Mean and median frequency')

 plot(MeanFreq, 'b')
 plot(MedianFreq, 'r')

 legend('MeanFreq','MedianFreq')
 hold off


 MeanFreq = [];
 MedianFreq = [];
 DEE = {};

 nummeasure = nummeasure + 1; % Change of measure to move on to the next one
 end
 p = pressio(marks2(i));
end